package start;

import java.util.Scanner;

public class Start_main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		 System.out.println("\u001B[32m====================================================");
		 	System.out.println("|   #    #  #   #  #    #   ######  ####   #     # |                   ");
		    System.out.println("|   #    #  #   #  ##   #  #        #   #   #   #  |                   ");
	        System.out.println("|   ######  #   #  # #  #  #  ####  ####      #    |                   ");
	        System.out.println("|   #    #  #   #  #  # #  #    ##  #   #     #    |                   ");
	        System.out.println("|   #    #   ###   #   ##   #### #  #    #    #    |                   ");
	        System.out.println("====================================================\u001B[0m");
	        System.out.println("");
	        System.out.println("\u001B[31;1;4;41;42;43;44;45;46m-------------------아무키나 눌러주세요!-------------------\u001B[0m");
	        sc.next();
	        System.out.println("\u001B[31;1;4;41;42;43;44;45;46m----------------------------------------------------\u001B[0m");
	        
	        
	        System.out.println("1.음식점 찾기");
	        System.out.println("2.음식점 랭킹");
	        System.out.println("3.음식점 추가");
	        System.out.println("4.음식점 삭제");
	        
//	        System.out.println("1.맛");
//	        System.out.println("2.거리");
//	        System.out.println("3.가격");
//	        System.out.println("4.종합");
	}

}
